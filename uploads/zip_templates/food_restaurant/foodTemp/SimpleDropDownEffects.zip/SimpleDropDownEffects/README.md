
SimpleDropDownEffects
=========

A jQuery plugin for transforming select inputs into drop-down lists with some simple expanding effects.

[article on Codrops](http://tympanus.net/codrops/?p=12452)

[demo](http://tympanus.net/Development/SimpleDropDownEffects)

Licensed under the MIT License